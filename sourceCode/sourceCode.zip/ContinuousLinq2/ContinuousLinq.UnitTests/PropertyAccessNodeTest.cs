using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using System.Windows;

namespace ContinuousLinq.UnitTests
{
    [TestFixture]
    [Ignore("Not used yet")]
    public class PropertyAccessNodeTest
    {
        //private PropertyAccessNode _target;

        [SetUp]
        public void Setup()
        {
        }
    }
}
