namespace ContinuousLinq.OrderBookDemo.Models
{
	public class Order
	{
		public double Ask { get; set; }
		public double Bid { get; set; }
		public double Price { get; set; }
	}
}