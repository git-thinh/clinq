**Project Description**
Continous LINQ is a .NET Framework 3.5 extension that builds on the LINQ query syntax to create continuous, self-updating result sets. 
In traditional LINQ queries, you write your query and get stale results. With Continuous LINQ, 

you write a query and the results of that query are continuously updated as changes are made to the source collection or items within the source collection. 

CLINQ has tremendous value in GUI development and is especially useful in binding to filtered streams of data such as financial or other network message data.

**[Getting Started](Getting-Started)**
* [Hello World - CLINQ Style](Hello-World---CLINQ-Style)
* [How CLINQ Works](How-CLINQ-Works)
* [Sample Usage Scenarios](Sample-Usage-Scenarios)
* [Continuous Aggregation](Continuous-Aggregation)

**Reactive Programming**
* [ReactiveObject](http://kutruff.wordpress.com/2009/07/14/reactive-programming-in-c-reactiveobject/) NOTE: **You must now also call OnPropertyChanging in addition to OnPropertyChanged when using ReactiveObject**

**[Feature Roadmap](Feature-Roadmap)** - What we're thinking of adding to CLINQ in the future

**Advanced Scenarios**
* [Adding to a Source Collection from a Collection Changed Event Handler](Adding-to-a-Source-Collection-from-a-Collection-Changed-Event-Handler)

**Appendix and Reference**
* [CLINQ FAQ](CLINQ-FAQ)
* [Supported LINQ Syntax](Supported-LINQ-Syntax)
* [Supported Platforms](Supported-Platforms)
* [Andy Kutruff's Blog](http://kutruff.wordpress.com)
* [.NET Addict's CLINQ Blog Posts](http://dotnetaddict.dotnetdevelopersjournal.com/tags/?/clinq)
