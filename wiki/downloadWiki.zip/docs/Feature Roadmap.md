# Feature Roadmap

The following is a tentative list of some of the features that we're planning on implementing in upcoming releases of CLINQ. 
As features are implemented in the release, this page will be updated. The idea is that the tentative feature plans will actually make it into the release notes and description for each release.

## CLINQ v2.3.0.0
* OrderBy improvements to prevent removal and addition to a list

Please suggest new features.