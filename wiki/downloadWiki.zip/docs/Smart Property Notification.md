# Smart Property Notification

Smart Property Notification was added to CLINQ in the [release:16757](release_16757) release.