# CLINQ Supported Platforms

Currently CLINQ has been tested to work on the following platforms:

* Full .NET Framework 3.5 (Windows Vista , Windows XP SP 2, etc)

The following platforms are planned but have not yet been implemented / tested :

* .NET Compact Framework v3.5 (Windows Mobile 6, etc)
* Silverlight 2.0+